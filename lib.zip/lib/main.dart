import 'package:flutter/material.dart';
import 'package:flutter_application/src/presentation/bloc/order/order_bloc.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'src/constants/routes.dart';
import 'src/presentation/screens/home/home_screen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // Da aggiungere
    return MultiBlocProvider(
      providers: [
        BlocProvider<OrderBloc>(
          create: (_) => OrderBloc(),
        ),
      ],
      child: MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'SPESPF-client',
          theme: ThemeData(fontFamily: 'Roboto', primaryColor: Colors.blueGrey),
          initialRoute: HomeScreen.routeName,
          routes: routes),
    );
  }
}

