import 'package:flutter/material.dart';
import 'package:flutter_application/src/presentation/screens/home/home_screen.dart';

final Map<String, WidgetBuilder> routes = {
  HomeScreen.routeName: (context) => const HomeScreen(title: 'Home',),
};